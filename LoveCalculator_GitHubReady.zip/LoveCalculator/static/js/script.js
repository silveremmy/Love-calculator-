document.addEventListener('DOMContentLoaded', function() {
    // Get references to DOM elements
    const calculateBtn = document.getElementById('calculate-btn');
    const name1Input = document.getElementById('name1');
    const name2Input = document.getElementById('name2');
    const resultContainer = document.getElementById('result-container');
    const percentage = document.getElementById('percentage');
    const resultText = document.getElementById('result-text');
    
    // Add event listener to the calculate button
    calculateBtn.addEventListener('click', calculateLove);
    
    // Allow calculation when pressing Enter in the input fields
    name1Input.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') calculateLove();
    });
    
    name2Input.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') calculateLove();
    });
    
    /**
     * Calculates the love percentage between two names and displays the result
     */
    function calculateLove() {
        // Get and trim the input values
        const name1 = name1Input.value.trim();
        const name2 = name2Input.value.trim();
        
        // Validate inputs
        if (name1 === '' || name2 === '') {
            alert('Please enter both names!');
            return;
        }
        
        // Show loading state
        percentage.textContent = '...';
        resultContainer.classList.add('visible');
        
        // Add a slight delay to create a "calculating" effect
        setTimeout(() => {
            // Generate love percentage (between 50-100%)
            const lovePercent = calculateLovePercentage(name1, name2);
            
            // Update the DOM with the result
            percentage.textContent = lovePercent + '%';
            resultText.innerHTML = `<span>${name1}</span> ❤️ <span>${name2}</span> = ${lovePercent}% compatibility!`;
            
            // Add some fun messages based on the percentage
            addLoveMessage(lovePercent);
        }, 800);
    }
    
    /**
     * Calculates a love percentage based on the names
     * This uses a deterministic algorithm so the same names always get the same result
     * 
     * @param {string} name1 - First name
     * @param {string} name2 - Second name
     * @returns {number} - Love percentage between 50-100%
     */
    function calculateLovePercentage(name1, name2) {
        // To make the result consistent for the same pair of names
        const combinedNames = (name1.toLowerCase() + name2.toLowerCase());
        
        // Generate a "hash" based on character codes
        let hash = 0;
        for (let i = 0; i < combinedNames.length; i++) {
            hash = (hash + combinedNames.charCodeAt(i) * (i + 1)) % 50;
        }
        
        // Return a value between 50-100%
        return hash + 50;
    }
    
    /**
     * Adds a fun message to the result text based on the percentage
     * 
     * @param {number} percentage - The calculated love percentage
     */
    function addLoveMessage(percentage) {
        let message = '';
        
        if (percentage >= 90) {
            message = 'Perfect match! You two are meant to be together! 💍';
        } else if (percentage >= 80) {
            message = 'Amazing chemistry! This could be true love! 💖';
        } else if (percentage >= 70) {
            message = 'Great potential! There\'s definitely something special here! ✨';
        } else if (percentage >= 60) {
            message = 'Good compatibility! Give it a chance! 🌟';
        } else {
            message = 'There\'s some chemistry, but it might need work! 🔄';
        }
        
        // Create a paragraph element for the message
        const messagePara = document.createElement('p');
        messagePara.textContent = message;
        messagePara.className = 'love-message';
        
        // Remove any existing message
        const existingMessage = document.querySelector('.love-message');
        if (existingMessage) {
            existingMessage.remove();
        }
        
        // Add the new message after the result text
        resultText.insertAdjacentElement('afterend', messagePara);
    }
});
